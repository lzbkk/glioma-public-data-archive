# Data Integrity Supplement Draft

Date: 20260702

Status: draft scaffold for possible R1-stage data/figure responsibility reporting; not submission-frozen.

## Scope

This draft supports journal or reviewer requests for a data integrity supplement mapping manuscript figures, supplementary figures and source-data packages to responsible authors.

## Figure Responsibility Table

| Display item | Primary data/source package | Responsible author(s) | Verification status | Notes |
|---|---|---|---|---|
| Figure 1 | Source Data Package / Figure_1 | [TBD] | [TBD] | bulk context, anchor benchmark, composition boundary |
| Figure 2 | Source Data Package / Figure_2 | [TBD] | [TBD] | frozen state and submodule decomposition |
| Figure 3 | Source Data Package / Figure_3 | [TBD] | [TBD] | Core GBmap donor-state decomposition |
| Figure 4 | Source Data Package / Figure_4 | [TBD] | [TBD] | GBM-Space spatial topology; tumor-level inference |
| Figure 5 | Source Data Package / Figure_5 | [TBD] | [TBD] | CPTAC/GLASS evidence boundary |
| Supplementary Fig. S4A | Source Data Package / Supplementary_Figure_S4A | [TBD] | [TBD] | representative GBM-Space spatial map; visualization only; public source-data file is a restricted-data placeholder, not the controlled spot-level coordinate/score table |

## Package Responsibility Table

| Package/file | Responsible author(s) | Verification status | Notes |
|---|---|---|---|
| Source_Data_Package_20260702.tar.gz | [TBD] | [TBD] | derived source data and supplementary inputs only |
| Journal_Supplementary_Tables_20260702.tar.gz | [TBD] | [TBD] | journal-facing supplementary workbooks |
| Supplementary_Tables_1_11_JournalFacing.xlsx | [TBD] | [TBD] | combined supplementary workbook |

## Boundary

- This draft does not replace author contribution statements.
- Do not list AI tools as responsible authors.
- Fill only after final author roster and contribution roles are confirmed.
- The package does not redistribute controlled-access raw data or third-party raw matrices.
- The public package does not redistribute the Supplementary Fig. S4A spot-level GBM-Space coordinate/score table; it retains only a section-level provenance/summary placeholder.
