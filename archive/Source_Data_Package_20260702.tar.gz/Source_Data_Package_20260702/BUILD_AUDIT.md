# Source Data Package Build Audit

Date: 20260702

## Counts

- Source-data rows copied: 30/30
- Supporting figure tables copied: 18/18
- Supplementary expanded files copied: 62/62
- Missing files: 0

## Blocking Issues

- None at the file-copy level.
- Public-release compliance adjustment on 2026-07-03: the Supplementary Fig. S4A spot-level GBM-Space representative-map source table was moved out of the public package and replaced by a section-level provenance/summary placeholder, because the underlying GBM-Space Visium data are controlled-access.

## Not Yet Submission-Frozen

- Zenodo draft has been created but not published: https://zenodo.org/deposit/21161701; reserved DOI 10.5281/zenodo.21161701.
- Public GitHub repository is fixed as https://github.com/lzbkk/glioma-public-data-archive.
- Final generated-data and code licences require author confirmation.
- GBM-Space journal-version status was rechecked on 2026-07-02 and must be rechecked again on upload day.
- CGGA portal-preferred citation was rechecked on 2026-07-02 and fixed to DOI 10.1016/j.gpb.2020.10.005.
