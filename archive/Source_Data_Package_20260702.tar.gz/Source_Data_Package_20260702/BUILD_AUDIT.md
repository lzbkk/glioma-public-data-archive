# Source Data Package Build Audit

Date: 20260702

## Counts

- Source-data rows copied: 30/30
- Supporting figure tables copied: 18/18
- Supplementary expanded files copied: 62/62
- Missing files: 0

## Blocking Issues

- None at the file-copy level.

## Not Yet Submission-Frozen

- Zenodo DOI/record URL is not created.
- Public GitHub repository is fixed as https://github.com/lzbkk/glioma-public-data-archive.
- Final generated-data and code licences require author confirmation.
- GBM-Space journal-version status was rechecked on 2026-07-02 and must be rechecked again on upload day.
- CGGA portal-preferred citation was rechecked on 2026-07-02 and fixed to DOI 10.1016/j.gpb.2020.10.005.
