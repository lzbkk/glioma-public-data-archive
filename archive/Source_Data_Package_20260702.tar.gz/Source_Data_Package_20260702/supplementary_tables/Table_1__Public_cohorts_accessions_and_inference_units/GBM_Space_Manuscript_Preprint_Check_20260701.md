# GBM-Space Manuscript / Preprint Check 20260701

## Routing

```text
Task: confirm whether GBM-Space has a peer-reviewed article or stable preprint
Skill: nature-academic-search
Search date: 2026-07-01
Foreground/background: lightweight citation verification; foreground
```

## Question

Does the GBM-Space Visium resource used in this project have a peer-reviewed
article or stable preprint that should be cited alongside the EGA accession?

## Sources Checked

| Source | Query or record | Result |
|---|---|---|
| GBM-Space portal | Publications section | Lists two submitted manuscripts with bioRxiv preprints. |
| GBM-Space portal | Integrated single cell and spatial data section | Describes integration of 1 million single-nucleus transcriptomes with 0.3 million spatial transcriptomes over 97 Visium sections. |
| EGA dataset | `EGAD00001015527` | Official Visium dataset record for GBM-Space. |
| EGA study | `EGAS00001005801` | Official study record; recommends citing accession plus EGA archive paper. |
| CrossRef / DOI lookup | `10.1101/2025.05.13.653495` | Stable bioRxiv DOI for the spatial/trajectory GBM-Space manuscript. |
| CrossRef / DOI lookup | `10.1101/2025.05.13.653733` | Stable bioRxiv DOI for the related single-cell multiomics/plasticity manuscript. |
| PubMed | `"GBM-Space"` | No records found on 2026-07-01. |
| PubMed | `"A spatiotemporal cancer cell trajectory underlies glioblastoma heterogeneity"` | No records found on 2026-07-01. |

## Finding

As of 2026-07-01, no peer-reviewed article was found for the GBM-Space Visium
atlas. The GBM-Space portal lists the relevant manuscript as submitted and links
to a stable bioRxiv preprint:

```text
de Jong G. et al.
A spatiotemporal cancer cell trajectory underlies glioblastoma heterogeneity.
bioRxiv 2025.
DOI: 10.1101/2025.05.13.653495
```

This is the correct manuscript/preprint citation for the current GBM-Space
Visium spatial topology work because its abstract and portal context describe a
paired single-cell and spatial multi-region atlas of 12 IDH-wildtype primary
glioblastomas and the spatially patterned cancer-cell trajectory.

The second portal-linked preprint,
`10.1101/2025.05.13.653733`, is relevant to single-cell multiomics and
plasticity/regulatory trajectories, but it is not the primary citation for this
project's current Visium spatial topology analyses.

## Citation Decision

Use all of the following at first mention of GBM-Space in the manuscript:

```text
1. de Jong et al. 2025 bioRxiv preprint, DOI 10.1101/2025.05.13.653495.
2. EGA dataset accession EGAD00001015527.
3. EGA study accession EGAS00001005801.
4. EGA archive paper, DOI 10.1093/nar/gkab1059, if the journal requires a formal archive citation.
```

Do not use BioStudies DOI `10.6019/s-biad2898` for the current Visium analysis;
that record is platform-mismatched to Xenium.

## Boundary

The preprint is stable and citable, but not peer-reviewed. Manuscript wording
should avoid phrasing such as "published GBM-Space study" until a journal
version is verified. Use "GBM-Space portal and accompanying preprint" or
"GBM-Space preprint and EGA dataset" instead.

## Submission Checklist

```text
Before submission:
  - Recheck DOI 10.1101/2025.05.13.653495 for a journal version.
  - Recheck PubMed and CrossRef by title.
  - If a peer-reviewed version exists, cite the journal article plus EGA accession.
  - Keep EGA dataset/study accession in Data Availability regardless of article status.
```
